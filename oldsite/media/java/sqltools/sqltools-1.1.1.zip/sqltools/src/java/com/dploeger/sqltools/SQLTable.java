package com.dploeger.sqltools;

/**
 * This class represents tables and table-joins for the SQLBuilder
 *
 * Copyright (C) 2007 Dennis Ploeger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * @author Dennis Ploeger <develop@dieploegers.de>
 * @version %I%, %G%
 * @since 1.0
 */
 
public class SQLTable {

    public String tableName = null;
    public String alias = null;

    public SQLTable joinedTable = null;
    public String joinConditionKey = null;
    public String joinConditionForeignKey = null;
    public String joinType = "INNER";

    // public methods
    
    /**
     * The connector with only a table name
     *
     * @param tableName the name for the table to include into the from-clause
     * @since 1.0
     */

    public SQLTable (String tableName) {

        this.tableName = tableName;

    }

    /**
     * The connector with a table name and an alias
     *
     * @param tableName the name for the table to include into the from-clause
     * @param alias     the alias for the table to be used in the select- or whereclause
     * @since 1.0
     */

    public SQLTable (String tableName, String alias) {

        this.tableName = tableName;
        this.alias = alias;

    }

    /**
     * Create a join to another table.
     * 
     * @param joinedTable             give the SQLTable-object for the joined table
     * @param joinConditionKey        give the column in this table as part of the join-condition
     * @param joinConditionForeignKey give the column in the joined table as part of the join-condition
     * @since 1.0
     */

    public void SetJoin (SQLTable joinedTable, String joinConditionKey, String joinConditionForeignKey) {

        this.joinedTable = joinedTable;
        this.joinConditionKey = joinConditionKey;
        this.joinConditionForeignKey = joinConditionForeignKey;

    }
    
    /**
     * Create a join to another table with setting the JOIN-type
     * 
     * @param joinedTable             give the SQLTable-object for the joined table
     * @param joinConditionKey        give the column in this table as part of the join-condition
     * @param joinConditionForeignKey give the column in the joined table as part of the join-condition
     * @since 1.0
     */

    public void SetJoin (SQLTable joinedTable, String joinConditionKey, String joinConditionForeignKey, String joinType) {

        this.joinedTable = joinedTable;
        this.joinConditionKey = joinConditionKey;
        this.joinConditionForeignKey = joinConditionForeignKey;
        this.joinType = joinType;

    }

}

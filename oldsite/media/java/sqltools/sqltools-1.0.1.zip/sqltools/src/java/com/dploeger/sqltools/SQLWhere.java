package com.dploeger.sqltools;

import java.util.ArrayList;

/**
 * This class represents parts of the Where-Clause for the SQLBuilder
 * 
 * Copyright (C) 2007 Dennis Ploeger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * @author Dennis Ploeger <develop@dieploegers.de>
 * @version $I$, $G%
 * @since 1.0
 */
 
public class SQLWhere {

    public String tableName = null;
    public String columnExpression = null;
    public String valueExpression = null;
    public String connectString = "AND";

    public ArrayList andWheres = null;
    public ArrayList orWheres = null; 

    // public methods

    /**
     * A constructor for a part of a where clause connected with an "AND" to the rest of the clause
     * 
     * @param tableName         the name of the table the columnExpression refers to
     * @param columnExpression  the column (or expression) for the where-clause
     * @param valueExpression   the expression, that contains the comparing functions for this part of the where-clause
     * @since 1.0
     */

    public SQLWhere (String tableName, String columnExpression, String valueExpression) {

        this.tableName = tableName;
        this.columnExpression = columnExpression;
        this.valueExpression = valueExpression;

    }

    /**
     * A constructor for a part of a where clause
     * 
     * @param tableName         the name of the table the columnExpression refers to
     * @param columnExpression  the column (or expression) for the where-clause
     * @param valueExpression   the expression, that contains the comparing functions for this part of the where-clause
     * @param connectString     if you like to connect this part of the where clause with an "OR" to the other parts, specify "OR" here.
     * @since 1.0
     */

    public SQLWhere (String tableName, String columnExpression, String valueExpression, String connectString) {

        this.tableName = tableName;
        this.columnExpression = columnExpression;
        this.valueExpression = valueExpression;
        this.connectString = connectString;

    }

    /**
     * Add another part of the where clause, connected with an "AND" to this part of the where-clause
     *
     * @param andWhere  the SQLWhere-object of the other part of the where clause to connect to
     * @since 1.0
     */

    public void AddAndWhere (SQLWhere andWhere) {

        if (this.andWheres == null) {

            this.andWheres = new ArrayList();

        }

        this.andWheres.add(andWhere);

    }

    /**
     * Add another part of the where clause, connected with an "OR" to this part of the where-clause
     *
     * @param orWhere  the SQLWhere-object of the other part of the where clause to connect to
     * @since 1.0
     */

    public void AddOrWhere (SQLWhere orWhere) {

        if (this.orWheres == null) {

            this.orWheres = new ArrayList();

        }

        this.orWheres.add(orWhere);

    }

}


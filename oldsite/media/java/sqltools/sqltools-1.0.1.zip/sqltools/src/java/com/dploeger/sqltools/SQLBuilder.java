package com.dploeger.sqltools;

import java.util.ArrayList;

import com.dploeger.sqltools.*;

/**
 * The SQLBuilder is a tool based on a set of classes to easily build SQL-statements
 * You only have to build some table, select or where-clause-objects and add them together
 * the way you want and push them all into the SQLBuilder-object and run build() to
 * get the SQL-statement.
 *
 * Copyright (C) 2007 Dennis Ploeger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * @author Dennis Ploeger <develop@dieploegers.de>
 * @version %I%, %G%
 * @since 1.0
 */

public class SQLBuilder {

    public ArrayList sqlSelects = null;
    public ArrayList sqlTables = null;
    public ArrayList sqlWheres = null;

    public boolean joinCompatible = false;

    // Public methods

    /**
     * Constructur for the class. (without Wheres)
     * 
     * @param sqlSelects    The SQLSelect-objects to describe the select-clause
     * @param sqlTables     The SQLTable-objects to describe the from-clause
     * @since 1.0
     */

    public SQLBuilder (ArrayList sqlSelects, ArrayList sqlTables) {

        this.sqlSelects = sqlSelects;
        this.sqlTables = sqlTables;

    }

    /**
     * Constructor for the class. (with Wheres)
     *
     * @param sqlSelects    The SQLSelect-objects to describe the select-clause
     * @param sqlTables     The SQLTable-objects to describe the from-clause
     * @param sqlWheres     The SQLWhere-objects to describe the where clause
     * @since 1.0
     */
    
    public SQLBuilder (ArrayList sqlSelects, ArrayList sqlTables, ArrayList sqlWheres) {

        this.sqlSelects = sqlSelects;
        this.sqlTables = sqlTables;
        this.sqlWheres = sqlWheres;

    }

    /**
     * Builds the SQL statement based on the SQLSelect, SQLTable and (optionally) SQLWhere-Objects provided
     * in the constructor
     *
     * @return the SQL-Statement as a String
     */

    public String build() {

        String sql = "";

        sql += "SELECT ";

        // Insert Selects

        for (int i=0; i < this.sqlSelects.size(); i++) {

            SQLSelect currentSelect = (SQLSelect) this.sqlSelects.get(i);

            sql += currentSelect.tableName+
                   "."+
                   currentSelect.columnExpression;

            if (currentSelect.alias != null) {    

                sql += " AS \""+currentSelect.alias+"\"";

            }
                  
            if (i < this.sqlSelects.size() -1) {

                sql += ", ";

            }

        }

        sql += " FROM ";

        // Insert Tables

        for (int i=0; i < this.sqlTables.size(); i++) {

            SQLTable currentTable = (SQLTable) this.sqlTables.get(i);

            sql += formatTable(currentTable);

            if (i < this.sqlTables.size() -1) {

                sql += ", ";

            }


        }

        if (this.sqlWheres.size() > 0) {

            // Add Wheres

            sql += " WHERE ";

            for (int i=0; i < this.sqlWheres.size(); i++) {

                SQLWhere currentWhere = (SQLWhere) this.sqlWheres.get(i);

                if (i > 0) {

                    sql += currentWhere.connectString+" ";

                }

                sql += formatWhere(currentWhere);


                if (i < this.sqlWheres.size() -1 ) {

                    sql += " ";

                }

            }

        }

        return sql;

    }

    // Private methods

    /**
     * Recursively writes parts of the From-Clause and goes into join-trees if there are any
     * 
     * @param currentTable SQLTable-object to work on
     * @return the generated part of the FROM-Clause
     * @since 1.0
     */

    private String formatTable(SQLTable currentTable) {

        String sql = "";

        sql += currentTable.tableName;

        if (currentTable.alias != null) {

            sql += " " + currentTable.alias;

        }

        if (currentTable.joinedTable != null) {

            if (!this.joinCompatible) {

                sql += " join " + formatTable(currentTable.joinedTable) + " on ";

                if (currentTable.alias != null) {

                    sql += currentTable.alias;

                } else {

                    sql += currentTable.tableName;

                }

                sql += "."+currentTable.joinConditionKey;

                sql += " = ";

                if (currentTable.joinedTable.alias != null) {

                    sql += currentTable.joinedTable.alias;

                } else {

                    sql += currentTable.joinedTable.tableName;

                }

                sql += "."+currentTable.joinConditionForeignKey;

            }

        }

        return sql;

    }

    /**
     * Recursively create parts of the WHERE-clause
     * 
     * @param currentWhere the SQLWhere-Object to work on
     * @return the generated part of the WHERE-clause
     */

    private String formatWhere(SQLWhere currentWhere) {

        String sql = "";

        sql += "(";

        sql += currentWhere.tableName+"."+currentWhere.columnExpression+" "+currentWhere.valueExpression;

        if (currentWhere.andWheres != null) {

            // Attach AND-Clauses

            for (int i=0; i < currentWhere.andWheres.size(); i++) {

                sql += " AND "+formatWhere((SQLWhere) currentWhere.andWheres.get(i));

            }

        }    

        if (currentWhere.orWheres != null) {

            // Attach OR-Clauses

            for (int i=0; i < currentWhere.orWheres.size(); i++) {

                sql += " OR "+formatWhere((SQLWhere) currentWhere.orWheres.get(i));

            }

        }    

        sql += ")";

        return sql;

    }

}


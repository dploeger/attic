package com.dploeger.sqltools;

/**
 * This class is a base class for the SQLBuilder-object and represents a part of
 * the SQL-Select-clause.
 *
 * Copyright (C) 2007 Dennis Ploeger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * @author Dennis Ploeger <develop@dieploegers.de>
 * @version %I%, %G%
 * @since 1.0
 */

public class SQLSelect {

    public String tableName = null;
    public String columnExpression = null;
    public String alias = null;

    // public methods

    /**
     * Constructor for SQLSelect without an alias.
     *
     * @param tableName         provide the tableName or alias that the given column refers to.
     * @param columnExpression  give a column or an expression (like cola || colb etc..) to include into the select-clause
     * @since 1.0
     */

    public SQLSelect (String tableName, String columnExpression) {

        this.tableName = tableName;
        this.columnExpression = columnExpression;

    }

    /**
     * Constructor for SQLSelect with an alias.
     *
     * @param tableName         provide the tableName or alias that the given column refers to.
     * @param columnExpression  give a column or an expression (like cola || colb etc..) to include into the select-clause
     * @param alias             an alias (or column header) for this part of the select-clause
     * @since 1.0
     */

    public SQLSelect (String tableName, String columnExpression, String alias) {

        this.tableName = tableName;
        this.columnExpression = columnExpression;
        this.alias = alias;

    }

}

